# Triangulito Discord Bot

Discord music + moderation + AI bot. Codebase fork of Discord-MusicBot (discord.js v13, erela.js v3, Lavalink). Bot user: **Triangulito#6462**. Spanish-speaking owner.

## Stack
- Node 20, discord.js v13, erela.js v3 (uses `MessageEmbed`, `MessageActionRow`, `MessageButton` APIs).
- Local Lavalink v3.7.13 on port 8080 (Java GraalVM 22.3.1), youtube-source plugin 1.13.5.
- Storage: `jsoning` JSON files in `Discord-MusicBot/data/` (auto-created).

## Workflows
- **Lavalink**: `cd lavalink && java -jar Lavalink.jar` (port 8080, console output).
- **Start application**: `cd Discord-MusicBot && node index.js`.

## Secrets (env vars)
- `DISCORD_TOKEN` — bot token (required).
- `GOOGLE_API_KEY` — used by `/ask` (Gemini) and search-grounding tool.
- `clientId` — only needed for `npm run deploy`. Current value: `1459382453968834590` (derivable from token base64). Not persisted as secret.

## Commands (61 slash + 1 context menu)
Loaded auto from `commands/slash/` (alphabetical) + `commands/context/`.
- **Music** (~35): play, pause, resume, skip, queue, loop, lyrics, filters, etc. (original repo).
- **Moderation/admin** (15): admin, ban, kick, timeout, untimeout, unban, warn, purge, lock, unlock, slowmode, role, nick, userinfo, serverinfo. `/admin` creates a "triangulito" role with bot-level perms.
- **Fun/AI** (4): akinator (button-based via `util/AkinatorHandler.js`, sessions in `client.akinatorSessions` Map), google (DuckDuckGo Instant Answer), wiki (Wikipedia REST), ask (Gemini 2.5 Flash + googleSearch grounding).
- **Economy** (6): balance, daily (24h, 500c), work (1h, 10–350c), pay, leaderboard, give (admin).
- **Welcome/Goodbye** (2 cfg): setwelcome, setgoodbye — each with `set/disable/test` subcommands. Variables: `{user} {server} {count}`.

## Events (8)
Auto-loaded from `events/` (filename = event name): interactionCreate, messageCreate, messageDelete, raw, ready, voiceStateUpdate, guildMemberAdd (welcome), guildMemberRemove (goodbye).

## Intents
GUILDS, GUILD_VOICE_STATES, GUILD_MESSAGES, GUILD_MEMBERS. Note: `GUILD_MEMBERS` is **privileged** — must be enabled in Discord Developer Portal for welcome/goodbye to fire.

## Key files
- `lib/DiscordMusicBot.js` — client, command loader (lines ~495), event loader (line ~480), intents (line ~36).
- `util/economyDB.js` — singleton wrappers around 2 jsoning DBs (`economy.json`, `welcome.json`). Keys: `guildId:userId` for economy, `welcome:guildId` / `goodbye:guildId` for greetings.
- `util/AkinatorHandler.js` + `events/interactionCreate.js` — handles `aki_*` button customIds.
- `deploy/deployGlobal.js` — overwrites Discord-side command registry (run with `clientId=... node deploy/deployGlobal.js` from Discord-MusicBot/).
- `config.js` / `util/getConfig.js` — bot config (Lavalink: `127.0.0.1:8080` / `youshallnotpass`).
- `lavalink/application.yml` — Lavalink config with youtube-plugin.

## Critical install lessons
- `aki-api` and `@google/genai` MUST be installed inside `Discord-MusicBot/` with `--save` (writes to its `package.json`). Root-level installs break `aki-api`'s `node_extra_ca_certs_mozilla_bundle` which opens its CA file at a path relative to cwd. Using `--no-save` also breaks future installs because npm rebuilds the tree from package.json.

## Known harmless warnings
- Lavalink: `Unexpected op "ready"` — cosmetic mismatch between erela.js v3 and Lavalink v3.7+ protocol; doesn't affect playback.
- Spotify token renewal failures — only matters if Spotify URLs are queued.

## Deploy notes
- Discord may take **up to 1 hour** to propagate global slash command changes (typical: a few minutes).
- Re-running `deployGlobal.js` REPLACES the entire global command list — ideal for cleaning up ghost commands from previous bots on the same token.
