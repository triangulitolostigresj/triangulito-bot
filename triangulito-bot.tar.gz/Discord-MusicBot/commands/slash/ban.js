const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("ban")
        .setDescription("Banea a un usuario del servidor")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario a banear").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón del baneo").setRequired(false))
        .addIntegerOption((o) => o.setName("borrar_dias").setDescription("Días de mensajes a borrar (0-7)").setMinValue(0).setMaxValue(7).setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Banear Miembros**.")] });
                }
                const me = interaction.guild.me || (await interaction.guild.members.fetchMe());
                if (!me.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El bot necesita el permiso **Banear Miembros**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const reason = interaction.options.getString("razon") || "Sin razón especificada";
                const days = interaction.options.getInteger("borrar_dias") ?? 0;

                if (user.id === interaction.user.id) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes banearte a ti mismo.")] });
                }
                if (user.id === client.user.id) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedo banearme a mí mismo.")] });
                }

                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (target) {
                        if (!target.bannable) {
                                return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedo banear a ese usuario (rol más alto que el mío o es dueño).")] });
                        }
                        if (target.roles.highest.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
                                return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes banear a alguien con un rol igual o superior al tuyo.")] });
                        }
                }

                try {
                        await interaction.guild.members.ban(user.id, { days, reason: `${interaction.user.tag}: ${reason}` });
                        return interaction.editReply({
                                embeds: [
                                        new MessageEmbed()
                                                .setColor(client.config.embedColor)
                                                .setTitle("🔨 Usuario baneado")
                                                .setDescription(`**${user.tag}** fue baneado.`)
                                                .addField("Razón", reason)
                                                .setFooter({ text: `Por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() }),
                                ],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
