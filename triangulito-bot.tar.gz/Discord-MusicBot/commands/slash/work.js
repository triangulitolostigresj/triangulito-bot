const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { getUser, setUser } = require("../../util/economyDB");

const COOLDOWN_MS = 60 * 60 * 1000;
const JOBS = [
  { name: "DJ", min: 50, max: 200 },
  { name: "programador", min: 80, max: 250 },
  { name: "cazador de monstruos", min: 30, max: 300 },
  { name: "repartidor", min: 40, max: 180 },
  { name: "panadero", min: 20, max: 150 },
  { name: "streamer", min: 10, max: 350 },
  { name: "minero", min: 60, max: 220 },
];

const command = new SlashCommand()
  .setName("work")
  .setDescription("Trabaja para ganar monedas (cada 1 h)")
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    const u = await getUser(interaction.guild.id, interaction.user.id);
    const now = Date.now();
    const elapsed = now - (u.lastWork || 0);
    if (elapsed < COOLDOWN_MS) {
      const remain = COOLDOWN_MS - elapsed;
      const m = Math.floor(remain / 60000);
      const s = Math.floor((remain % 60000) / 1000);
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription(`⏳ | Estás cansado. Descansa **${m}m ${s}s** más.`),
        ],
      });
    }
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];
    const earned = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;
    u.coins = (u.coins || 0) + earned;
    u.lastWork = now;
    await setUser(interaction.guild.id, interaction.user.id, u);
    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`💼 | Trabajaste como **${job.name}** y ganaste **${earned}** monedas.\n💰 Saldo: **${u.coins}**`),
      ],
    });
  });

module.exports = command;
