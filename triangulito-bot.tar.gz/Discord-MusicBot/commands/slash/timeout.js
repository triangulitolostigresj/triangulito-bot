const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("timeout")
        .setDescription("Silencia (timeout) a un usuario por X minutos")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
        .addIntegerOption((o) => o.setName("minutos").setDescription("Duración en minutos (máx 40320 = 28 días)").setMinValue(1).setMaxValue(40320).setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.MODERATE_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Moderar Miembros**.")] });
                }
                const me = interaction.guild.me || (await interaction.guild.members.fetchMe());
                if (!me.permissions.has(Permissions.FLAGS.MODERATE_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El bot necesita el permiso **Moderar Miembros**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const minutes = interaction.options.getInteger("minutos", true);
                const reason = interaction.options.getString("razon") || "Sin razón especificada";

                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (!target) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Ese usuario no está en el servidor.")] });
                if (!target.moderatable) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedo silenciar a ese usuario.")] });

                try {
                        await target.timeout(minutes * 60 * 1000, `${interaction.user.tag}: ${reason}`);
                        return interaction.editReply({
                                embeds: [
                                        new MessageEmbed()
                                                .setColor(client.config.embedColor)
                                                .setTitle("🔇 Usuario silenciado")
                                                .setDescription(`**${user.tag}** fue silenciado por **${minutes} minutos**.`)
                                                .addField("Razón", reason)
                                                .setFooter({ text: `Por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() }),
                                ],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
