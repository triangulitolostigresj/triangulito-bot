const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { getUser, setUser } = require("../../util/economyDB");

const COOLDOWN_MS = 24 * 60 * 60 * 1000;
const REWARD = 500;

const command = new SlashCommand()
  .setName("daily")
  .setDescription("Reclama tus monedas diarias (cada 24 h)")
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    const u = await getUser(interaction.guild.id, interaction.user.id);
    const now = Date.now();
    const elapsed = now - (u.lastDaily || 0);
    if (elapsed < COOLDOWN_MS) {
      const remain = COOLDOWN_MS - elapsed;
      const h = Math.floor(remain / 3600000);
      const m = Math.floor((remain % 3600000) / 60000);
      return interaction.editReply({
        embeds: [
          new MessageEmbed()
            .setColor("RED")
            .setDescription(`⏳ | Ya reclamaste tu diario. Vuelve en **${h}h ${m}m**.`),
        ],
      });
    }
    u.coins = (u.coins || 0) + REWARD;
    u.lastDaily = now;
    await setUser(interaction.guild.id, interaction.user.id, u);
    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`🎁 | Reclamaste **${REWARD}** monedas. Saldo total: **${u.coins}** 💰`),
      ],
    });
  });

module.exports = command;
