const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
        .setName("serverinfo")
        .setDescription("Muestra información del servidor")
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                const g = interaction.guild;
                await g.members.fetch().catch(() => null);
                const owner = await g.fetchOwner().catch(() => null);
                const humans = g.members.cache.filter((m) => !m.user.bot).size;
                const bots = g.members.cache.filter((m) => m.user.bot).size;
                const text = g.channels.cache.filter((c) => c.type === "GUILD_TEXT").size;
                const voice = g.channels.cache.filter((c) => c.type === "GUILD_VOICE").size;

                const embed = new MessageEmbed()
                        .setColor(client.config.embedColor)
                        .setTitle(`📊 ${g.name}`)
                        .setThumbnail(g.iconURL({ dynamic: true, size: 512 }) || null)
                        .addField("ID", g.id, true)
                        .addField("Dueño", owner ? owner.user.tag : "Desconocido", true)
                        .addField("Creado", `<t:${Math.floor(g.createdTimestamp / 1000)}:F>`, false)
                        .addField("Miembros", `👥 ${g.memberCount}\n👤 Humanos: ${humans}\n🤖 Bots: ${bots}`, true)
                        .addField("Canales", `💬 Texto: ${text}\n🔊 Voz: ${voice}`, true)
                        .addField("Roles", `${g.roles.cache.size}`, true)
                        .addField("Emojis", `${g.emojis.cache.size}`, true)
                        .addField("Nivel de boost", `Nivel ${g.premiumTier} (${g.premiumSubscriptionCount || 0} boosts)`, true);

                return interaction.editReply({ embeds: [embed] });
        });

module.exports = command;
