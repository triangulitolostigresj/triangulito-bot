const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");

const command = new SlashCommand()
        .setName("userinfo")
        .setDescription("Muestra información de un usuario")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario (por defecto tú)").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                const user = interaction.options.getUser("usuario") || interaction.user;
                const member = await interaction.guild.members.fetch(user.id).catch(() => null);

                const embed = new MessageEmbed()
                        .setColor(client.config.embedColor)
                        .setTitle(`👤 Información de ${user.tag}`)
                        .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 512 }))
                        .addField("ID", user.id, true)
                        .addField("Bot", user.bot ? "Sí" : "No", true)
                        .addField("Cuenta creada", `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`, false);

                if (member) {
                        embed.addField("Se unió al servidor", member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : "Desconocido", false);
                        const roles = member.roles.cache.filter((r) => r.id !== interaction.guild.id).sort((a, b) => b.position - a.position).map((r) => r.toString());
                        embed.addField(`Roles (${roles.length})`, roles.length ? roles.slice(0, 25).join(" ") : "Ninguno", false);
                        if (member.communicationDisabledUntilTimestamp && member.communicationDisabledUntilTimestamp > Date.now()) {
                                embed.addField("Timeout hasta", `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>`, false);
                        }
                }

                return interaction.editReply({ embeds: [embed] });
        });

module.exports = command;
