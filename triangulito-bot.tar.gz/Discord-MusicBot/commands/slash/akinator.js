const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const { Aki } = require("aki-api");

function buildAnswerRows(userId, answers) {
        const labels = ["Sí", "No", "No sé", "Probablemente", "Probablemente no"];
        const styles = ["SUCCESS", "DANGER", "SECONDARY", "PRIMARY", "PRIMARY"];
        const row1 = new MessageActionRow();
        for (let i = 0; i < Math.min(answers.length, 5); i++) {
                row1.addComponents(
                        new MessageButton().setCustomId(`aki_${userId}_${i}`).setLabel(labels[i] || answers[i]).setStyle(styles[i] || "PRIMARY")
                );
        }
        const row2 = new MessageActionRow().addComponents(
                new MessageButton().setCustomId(`aki_${userId}_back`).setLabel("⬅️ Atrás").setStyle("SECONDARY"),
                new MessageButton().setCustomId(`aki_${userId}_stop`).setLabel("🛑 Parar").setStyle("DANGER")
        );
        return [row1, row2];
}

function buildGuessRow(userId) {
        return new MessageActionRow().addComponents(
                new MessageButton().setCustomId(`aki_${userId}_winyes`).setLabel("✅ ¡Sí, acertó!").setStyle("SUCCESS"),
                new MessageButton().setCustomId(`aki_${userId}_winno`).setLabel("❌ No, sigue").setStyle("DANGER"),
                new MessageButton().setCustomId(`aki_${userId}_stop`).setLabel("🛑 Parar").setStyle("SECONDARY")
        );
}

const command = new SlashCommand()
        .setName("akinator")
        .setDescription("Juega Akinator: piensa en un personaje y trato de adivinarlo")
        .addStringOption((o) =>
                o.setName("idioma").setDescription("Idioma del juego").setRequired(false)
                        .addChoices({ name: "Español", value: "es" }, { name: "Inglés", value: "en" }, { name: "Francés", value: "fr" }, { name: "Portugués", value: "pt" })
        )
        .addBooleanOption((o) => o.setName("modo_infantil").setDescription("Filtrar contenido adulto").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!client.akinatorSessions) client.akinatorSessions = new Map();
                if (client.akinatorSessions.has(interaction.user.id)) {
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("YELLOW").setDescription("⚠️ Ya tienes una partida en curso. Termínala o presiona **Parar** primero.")],
                        });
                }

                const region = interaction.options.getString("idioma") || "es";
                const childMode = interaction.options.getBoolean("modo_infantil") ?? false;

                try {
                        const aki = new Aki({ region, childMode });
                        await aki.start();

                        client.akinatorSessions.set(interaction.user.id, { aki, lastInteraction: Date.now(), guessed: new Set() });

                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setAuthor({ name: `🧞 Akinator — partida de ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                                .setTitle(`Pregunta 1`)
                                .setDescription(`**${aki.question}**`)
                                .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%  •  Solo ${interaction.user.tag} puede responder` });

                        return interaction.editReply({ embeds: [embed], components: buildAnswerRows(interaction.user.id, aki.answers) });
                } catch (err) {
                        client.akinatorSessions.delete(interaction.user.id);
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ No pude iniciar Akinator: \`${err.message}\``)],
                        });
                }
        });

module.exports = command;
module.exports.buildAnswerRows = buildAnswerRows;
module.exports.buildGuessRow = buildGuessRow;
