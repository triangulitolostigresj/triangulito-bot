const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");
const { addCoins } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("give")
  .setDescription("(Admin) Da o quita monedas a un usuario")
  .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
  .addIntegerOption((o) => o.setName("cantidad").setDescription("Cantidad (negativo para quitar)").setRequired(true))
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Administrador**.")],
      });
    }
    const target = interaction.options.getUser("usuario", true);
    const amount = interaction.options.getInteger("cantidad", true);
    if (target.bot) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes dar monedas a un bot.")] });
    }
    const newBal = await addCoins(interaction.guild.id, target.id, amount);
    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`✅ | ${amount >= 0 ? "Diste" : "Quitaste"} **${Math.abs(amount)}** monedas a <@${target.id}>.\nSaldo nuevo: **${newBal}** 💰`),
      ],
    });
  });

module.exports = command;
