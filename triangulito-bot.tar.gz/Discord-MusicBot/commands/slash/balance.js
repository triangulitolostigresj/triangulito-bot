const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { getUser } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("balance")
  .setDescription("Muestra tus monedas (o las de otro usuario)")
  .addUserOption((o) => o.setName("usuario").setDescription("Usuario a consultar").setRequired(false))
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    const user = interaction.options.getUser("usuario") || interaction.user;
    const data = await getUser(interaction.guild.id, user.id);
    const embed = new MessageEmbed()
      .setColor(client.config.embedColor)
      .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
      .setDescription(`💰 **Monedas:** \`${data.coins}\``)
      .setFooter({ text: `Pedido por ${interaction.user.tag}` });
    return interaction.editReply({ embeds: [embed] });
  });

module.exports = command;
