const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");
const { welcome } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("setwelcome")
  .setDescription("(Admin) Configura el mensaje de bienvenida")
  .addSubcommand((s) =>
    s.setName("set")
      .setDescription("Activa la bienvenida en un canal")
      .addChannelOption((o) => o.setName("canal").setDescription("Canal donde se enviará").setRequired(true))
      .addStringOption((o) => o.setName("mensaje").setDescription("Variables: {user} {server} {count}").setRequired(false))
  )
  .addSubcommand((s) => s.setName("disable").setDescription("Desactiva las bienvenidas"))
  .addSubcommand((s) => s.setName("test").setDescription("Prueba el mensaje de bienvenida"))
  .setRun(async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });
    if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Gestionar Servidor**.")] });
    }
    const sub = interaction.options.getSubcommand();
    const key = `welcome:${interaction.guild.id}`;

    if (sub === "set") {
      const channel = interaction.options.getChannel("canal", true);
      const message = interaction.options.getString("mensaje") || "👋 ¡Bienvenido {user} a **{server}**! Ahora somos **{count}** miembros.";
      if (!channel.isText()) {
        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El canal debe ser de texto.")] });
      }
      await welcome.set(key, { enabled: true, channelId: channel.id, message });
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`✅ | Bienvenidas activadas en <#${channel.id}>.\n\n**Mensaje:**\n${message}`)],
      });
    }

    if (sub === "disable") {
      const cur = (await welcome.get(key)) || {};
      cur.enabled = false;
      await welcome.set(key, cur);
      return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription("✅ | Bienvenidas desactivadas.")] });
    }

    if (sub === "test") {
      const cur = await welcome.get(key);
      if (!cur || !cur.enabled || !cur.channelId) {
        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Las bienvenidas no están configuradas. Usa `/setwelcome set` primero.")] });
      }
      const ch = interaction.guild.channels.cache.get(cur.channelId);
      if (!ch) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El canal configurado ya no existe.")] });
      const msg = (cur.message || "")
        .replace(/{user}/g, `<@${interaction.user.id}>`)
        .replace(/{server}/g, interaction.guild.name)
        .replace(/{count}/g, interaction.guild.memberCount);
      await ch.send({ content: msg }).catch(() => null);
      return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`✅ | Mensaje de prueba enviado a <#${ch.id}>.`)] });
    }
  });

module.exports = command;
