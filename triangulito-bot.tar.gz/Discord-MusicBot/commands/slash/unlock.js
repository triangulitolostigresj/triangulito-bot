const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("unlock")
        .setDescription("Desbloquea el canal actual")
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas **Gestionar Canales**.")] });
                }
                const reason = interaction.options.getString("razon") || "Sin razón";
                try {
                        await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SEND_MESSAGES: null }, { reason: `${interaction.user.tag}: ${reason}` });
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`🔓 Canal desbloqueado.\n**Razón:** ${reason}`)] });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
