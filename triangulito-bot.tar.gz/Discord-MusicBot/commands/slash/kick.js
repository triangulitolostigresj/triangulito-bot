const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("kick")
        .setDescription("Expulsa a un usuario del servidor")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario a expulsar").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.KICK_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Expulsar Miembros**.")] });
                }
                const me = interaction.guild.me || (await interaction.guild.members.fetchMe());
                if (!me.permissions.has(Permissions.FLAGS.KICK_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El bot necesita el permiso **Expulsar Miembros**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const reason = interaction.options.getString("razon") || "Sin razón especificada";

                if (user.id === interaction.user.id) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes expulsarte a ti mismo.")] });
                }

                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (!target) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Ese usuario no está en el servidor.")] });
                }
                if (!target.kickable) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedo expulsar a ese usuario.")] });
                }
                if (target.roles.highest.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes expulsar a alguien con un rol igual o superior al tuyo.")] });
                }

                try {
                        await target.kick(`${interaction.user.tag}: ${reason}`);
                        return interaction.editReply({
                                embeds: [
                                        new MessageEmbed()
                                                .setColor(client.config.embedColor)
                                                .setTitle("👢 Usuario expulsado")
                                                .setDescription(`**${user.tag}** fue expulsado.`)
                                                .addField("Razón", reason)
                                                .setFooter({ text: `Por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() }),
                                ],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
