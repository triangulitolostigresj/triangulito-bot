const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { GoogleGenAI } = require("@google/genai");

let ai = null;
function getAI() {
        if (!ai) {
                const key = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;
                if (!key) throw new Error("Falta la variable GOOGLE_API_KEY (o GEMINI_API_KEY)");
                ai = new GoogleGenAI({ apiKey: key });
        }
        return ai;
}

const command = new SlashCommand()
        .setName("ask")
        .setDescription("Hazle una pregunta a la IA (Gemini) — busca en Google para darte respuestas reales y actuales")
        .addStringOption((o) => o.setName("pregunta").setDescription("Tu pregunta").setRequired(true))
        .addBooleanOption((o) => o.setName("sin_google").setDescription("Responder sin buscar en Google").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                const pregunta = interaction.options.getString("pregunta", true);
                const sinGoogle = interaction.options.getBoolean("sin_google") ?? false;

                try {
                        const genai = getAI();
                        const config = {
                                systemInstruction:
                                        "Eres un asistente útil dentro de un bot de Discord. Responde en español de forma clara, directa y concisa (máximo 1500 caracteres). Si usas información de la web, cítala. No uses markdown pesado, solo negritas o emojis ocasionales.",
                        };
                        if (!sinGoogle) {
                                config.tools = [{ googleSearch: {} }];
                        }

                        const response = await genai.models.generateContent({
                                model: "gemini-2.5-flash",
                                contents: pregunta,
                                config,
                        });

                        let text = (response.text || "").trim();
                        if (!text) text = "🤔 La IA no devolvió respuesta. Intenta reformular la pregunta.";
                        if (text.length > 4000) text = text.slice(0, 3990) + "…";

                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setAuthor({ name: `🤖 ${sinGoogle ? "Gemini" : "Gemini + Google"}`, iconURL: "https://www.gstatic.com/lamda/images/gemini_sparkle_v002_d4735304ff6292a690345.svg" })
                                .setTitle((pregunta.length > 240 ? pregunta.slice(0, 240) + "…" : pregunta))
                                .setDescription(text)
                                .setFooter({ text: `Preguntado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

                        const grounding = response.candidates?.[0]?.groundingMetadata;
                        const chunks = grounding?.groundingChunks || [];
                        if (chunks.length) {
                                const sources = chunks
                                        .slice(0, 5)
                                        .map((c, i) => {
                                                const w = c.web;
                                                if (!w) return null;
                                                const title = (w.title || w.uri || "fuente").slice(0, 80);
                                                return `**${i + 1}.** [${title}](${w.uri})`;
                                        })
                                        .filter(Boolean)
                                        .join("\n");
                                if (sources) embed.addField("🔗 Fuentes", sources.slice(0, 1024));
                        }

                        return interaction.editReply({ embeds: [embed] });
                } catch (err) {
                        client.logger && client.logger.error && client.logger.error(err.stack || err.toString());
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ Error con la IA: \`${err.message}\``)],
                        });
                }
        });

module.exports = command;
