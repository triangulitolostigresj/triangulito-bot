const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { getTopUsers } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("leaderboard")
  .setDescription("Top 10 usuarios más ricos del servidor")
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    const top = await getTopUsers(interaction.guild.id, 10);
    if (!top.length) {
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor("YELLOW").setDescription("📉 | Aún no hay usuarios con monedas en este servidor.")],
      });
    }
    const medals = ["🥇", "🥈", "🥉"];
    const lines = await Promise.all(
      top.map(async (e, i) => {
        const u = await client.users.fetch(e.userId).catch(() => null);
        const tag = u ? u.tag : `Usuario(${e.userId})`;
        const prefix = medals[i] || `**${i + 1}.**`;
        return `${prefix} ${tag} — \`${e.coins}\` 💰`;
      })
    );
    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setTitle(`🏆 Top monedas — ${interaction.guild.name}`)
          .setDescription(lines.join("\n")),
      ],
    });
  });

module.exports = command;
