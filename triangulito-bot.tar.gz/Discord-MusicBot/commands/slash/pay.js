const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const { getUser, setUser } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("pay")
  .setDescription("Envía monedas a otro usuario")
  .addUserOption((o) => o.setName("usuario").setDescription("Usuario que recibe").setRequired(true))
  .addIntegerOption((o) => o.setName("cantidad").setDescription("Cantidad de monedas").setMinValue(1).setRequired(true))
  .setRun(async (client, interaction) => {
    await interaction.deferReply();
    const target = interaction.options.getUser("usuario", true);
    const amount = interaction.options.getInteger("cantidad", true);
    if (target.id === interaction.user.id) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes pagarte a ti mismo.")] });
    }
    if (target.bot) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedes enviar monedas a un bot.")] });
    }
    const sender = await getUser(interaction.guild.id, interaction.user.id);
    if ((sender.coins || 0) < amount) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | No tienes suficientes monedas. Tu saldo: **${sender.coins}**.`)] });
    }
    const receiver = await getUser(interaction.guild.id, target.id);
    sender.coins -= amount;
    receiver.coins = (receiver.coins || 0) + amount;
    await setUser(interaction.guild.id, interaction.user.id, sender);
    await setUser(interaction.guild.id, target.id, receiver);
    return interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setColor(client.config.embedColor)
          .setDescription(`💸 | <@${interaction.user.id}> envió **${amount}** monedas a <@${target.id}>.`),
      ],
    });
  });

module.exports = command;
