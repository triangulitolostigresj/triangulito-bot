const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("unban")
        .setDescription("Desbanea a un usuario por su ID")
        .addStringOption((o) => o.setName("id").setDescription("ID del usuario baneado").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Banear Miembros**.")] });
                }

                const id = interaction.options.getString("id", true);
                const reason = interaction.options.getString("razon") || "Sin razón especificada";

                if (!/^\d{17,20}$/.test(id)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | ID inválida.")] });
                }

                try {
                        const ban = await interaction.guild.bans.fetch(id).catch(() => null);
                        if (!ban) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Ese usuario no está baneado.")] });

                        await interaction.guild.members.unban(id, `${interaction.user.tag}: ${reason}`);
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor(client.config.embedColor).setTitle("✅ Usuario desbaneado").setDescription(`**${ban.user.tag}** (${id}) fue desbaneado.`).addField("Razón", reason)],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
