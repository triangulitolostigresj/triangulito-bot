const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("untimeout")
        .setDescription("Quita el timeout (silencio) a un usuario")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Razón").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.MODERATE_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Moderar Miembros**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const reason = interaction.options.getString("razon") || "Sin razón especificada";

                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (!target) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Ese usuario no está en el servidor.")] });

                try {
                        await target.timeout(null, `${interaction.user.tag}: ${reason}`);
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor(client.config.embedColor).setTitle("🔊 Timeout removido").setDescription(`Le quité el timeout a **${user.tag}**.`).addField("Razón", reason)],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
