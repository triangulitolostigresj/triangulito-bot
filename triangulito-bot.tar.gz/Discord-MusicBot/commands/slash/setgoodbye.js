const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");
const { welcome } = require("../../util/economyDB");

const command = new SlashCommand()
  .setName("setgoodbye")
  .setDescription("(Admin) Configura el mensaje de despedida")
  .addSubcommand((s) =>
    s.setName("set")
      .setDescription("Activa la despedida en un canal")
      .addChannelOption((o) => o.setName("canal").setDescription("Canal donde se enviará").setRequired(true))
      .addStringOption((o) => o.setName("mensaje").setDescription("Variables: {user} {server} {count}").setRequired(false))
  )
  .addSubcommand((s) => s.setName("disable").setDescription("Desactiva las despedidas"))
  .addSubcommand((s) => s.setName("test").setDescription("Prueba el mensaje de despedida"))
  .setRun(async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true });
    if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Gestionar Servidor**.")] });
    }
    const sub = interaction.options.getSubcommand();
    const key = `goodbye:${interaction.guild.id}`;

    if (sub === "set") {
      const channel = interaction.options.getChannel("canal", true);
      const message = interaction.options.getString("mensaje") || "👋 **{user}** se ha ido de **{server}**. Ahora somos **{count}** miembros.";
      if (!channel.isText()) {
        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El canal debe ser de texto.")] });
      }
      await welcome.set(key, { enabled: true, channelId: channel.id, message });
      return interaction.editReply({
        embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`✅ | Despedidas activadas en <#${channel.id}>.\n\n**Mensaje:**\n${message}`)],
      });
    }

    if (sub === "disable") {
      const cur = (await welcome.get(key)) || {};
      cur.enabled = false;
      await welcome.set(key, cur);
      return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription("✅ | Despedidas desactivadas.")] });
    }

    if (sub === "test") {
      const cur = await welcome.get(key);
      if (!cur || !cur.enabled || !cur.channelId) {
        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Las despedidas no están configuradas. Usa `/setgoodbye set` primero.")] });
      }
      const ch = interaction.guild.channels.cache.get(cur.channelId);
      if (!ch) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El canal configurado ya no existe.")] });
      const msg = (cur.message || "")
        .replace(/{user}/g, `**${interaction.user.tag}**`)
        .replace(/{server}/g, interaction.guild.name)
        .replace(/{count}/g, interaction.guild.memberCount);
      await ch.send({ content: msg }).catch(() => null);
      return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`✅ | Mensaje de prueba enviado a <#${ch.id}>.`)] });
    }
  });

module.exports = command;
