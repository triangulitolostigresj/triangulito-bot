const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("purge")
        .setDescription("Borra varios mensajes del canal (máx 100, hasta 14 días)")
        .addIntegerOption((o) => o.setName("cantidad").setDescription("Número de mensajes a borrar (1-100)").setMinValue(1).setMaxValue(100).setRequired(true))
        .addUserOption((o) => o.setName("usuario").setDescription("Solo borrar mensajes de este usuario").setRequired(false))
        .setRun(async (client, interaction) => {
                if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
                        return interaction.reply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Gestionar Mensajes**.")], ephemeral: true });
                }
                const me = interaction.guild.me || (await interaction.guild.members.fetchMe());
                if (!me.permissionsIn(interaction.channel).has(Permissions.FLAGS.MANAGE_MESSAGES)) {
                        return interaction.reply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El bot necesita el permiso **Gestionar Mensajes** en este canal.")], ephemeral: true });
                }

                await interaction.deferReply({ ephemeral: true });
                const cantidad = interaction.options.getInteger("cantidad", true);
                const user = interaction.options.getUser("usuario");

                try {
                        let messages = await interaction.channel.messages.fetch({ limit: 100 });
                        if (user) messages = messages.filter((m) => m.author.id === user.id);
                        const toDelete = Array.from(messages.values()).slice(0, cantidad);
                        const deleted = await interaction.channel.bulkDelete(toDelete, true);
                        return interaction.editReply({
                                embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`🧹 Borré **${deleted.size}** mensajes${user ? ` de **${user.tag}**` : ""}.`)],
                        });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\` (los mensajes de más de 14 días no se pueden borrar en bloque)`)] });
                }
        });

module.exports = command;
