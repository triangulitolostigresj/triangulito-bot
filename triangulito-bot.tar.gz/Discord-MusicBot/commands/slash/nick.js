const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("nick")
        .setDescription("Cambia el apodo de un usuario (déjalo vacío para quitar)")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
        .addStringOption((o) => o.setName("apodo").setDescription("Nuevo apodo (vacío = quitar)").setRequired(false))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_NICKNAMES)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas **Gestionar Apodos**.")] });
                }
                const user = interaction.options.getUser("usuario", true);
                const nick = interaction.options.getString("apodo") || null;
                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (!target) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Usuario no encontrado.")] });
                if (!target.manageable) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | No puedo cambiar el apodo de ese usuario.")] });
                try {
                        await target.setNickname(nick, `${interaction.user.tag} via /nick`);
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(nick ? `✏️ Apodo de **${user.tag}** cambiado a **${nick}**.` : `✏️ Apodo de **${user.tag}** removido.`)] });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
