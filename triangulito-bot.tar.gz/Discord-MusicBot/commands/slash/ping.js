const { MessageEmbed } = require("discord.js");
const SlashCommand = require("../../lib/SlashCommand");

const command = new SlashCommand()
  .setName("ping")
  .setDescription("View the bot's latency")
  .setRun(async (client, interaction) => {
    const sent = await interaction.deferReply({ fetchReply: true });

    const zap = "⚡";
    const green = "🟢";
    const red = "🔴";
    const yellow = "🟡";

    let botState = zap;
    let apiState = zap;

    const apiPing = client.ws.ping;
    const botPing = Math.floor(sent.createdTimestamp - interaction.createdTimestamp);

    if (apiPing >= 40 && apiPing < 200) apiState = green;
    else if (apiPing >= 200 && apiPing < 400) apiState = yellow;
    else if (apiPing >= 400) apiState = red;

    if (botPing >= 40 && botPing < 200) botState = green;
    else if (botPing >= 200 && botPing < 400) botState = yellow;
    else if (botPing >= 400) botState = red;

    await interaction.editReply({
      embeds: [
        new MessageEmbed()
          .setTitle("🏓 | Pong!")
          .addFields(
            {
              name: "API Latency",
              value: `\`\`\`yml\n${apiState} | ${apiPing}ms\`\`\``,
              inline: true,
            },
            {
              name: "Bot Latency",
              value: `\`\`\`yml\n${botState} | ${botPing}ms\`\`\``,
              inline: true,
            }
          )
          .setColor(client.config.embedColor)
          .setFooter({
            text: `Requested by ${interaction.user.tag}`,
            iconURL: interaction.user.avatarURL(),
          }),
      ],
    });
  });

module.exports = command;
