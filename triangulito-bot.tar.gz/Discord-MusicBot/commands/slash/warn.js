const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("warn")
        .setDescription("Advierte a un usuario (le envía un DM)")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario a advertir").setRequired(true))
        .addStringOption((o) => o.setName("razon").setDescription("Motivo de la advertencia").setRequired(true))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();

                if (!interaction.member.permissions.has(Permissions.FLAGS.MODERATE_MEMBERS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas el permiso **Moderar Miembros**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const reason = interaction.options.getString("razon", true);

                let dmStatus = "✅ DM enviado";
                try {
                        await user.send({
                                embeds: [
                                        new MessageEmbed()
                                                .setColor("YELLOW")
                                                .setTitle(`⚠️ Has sido advertido en ${interaction.guild.name}`)
                                                .addField("Razón", reason)
                                                .setFooter({ text: `Por ${interaction.user.tag}` }),
                                ],
                        });
                } catch {
                        dmStatus = "⚠️ No pude enviarle DM (lo tiene desactivado)";
                }

                return interaction.editReply({
                        embeds: [
                                new MessageEmbed()
                                        .setColor(client.config.embedColor)
                                        .setTitle("⚠️ Advertencia enviada")
                                        .setDescription(`**${user.tag}** fue advertido.`)
                                        .addField("Razón", reason)
                                        .addField("Estado", dmStatus)
                                        .setFooter({ text: `Por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() }),
                        ],
                });
        });

module.exports = command;
