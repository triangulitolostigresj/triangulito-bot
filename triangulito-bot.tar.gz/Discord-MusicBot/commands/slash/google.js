const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const fetch = require("node-fetch");

const command = new SlashCommand()
        .setName("google")
        .setDescription("Busca en internet (DuckDuckGo) y muestra los primeros resultados")
        .addStringOption((o) => o.setName("busqueda").setDescription("Qué quieres buscar").setRequired(true))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                const q = interaction.options.getString("busqueda", true);

                try {
                        const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&no_redirect=1&kl=es-es`, {
                                headers: { "User-Agent": "Mozilla/5.0 (compatible; Triangulito-Bot/1.0)" },
                        });
                        const data = await res.json();

                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setTitle(`🔎 Resultados para: ${q}`)
                                .setURL(`https://duckduckgo.com/?q=${encodeURIComponent(q)}`)
                                .setFooter({ text: `Solicitado por ${interaction.user.tag} • powered by DuckDuckGo`, iconURL: interaction.user.displayAvatarURL() });

                        let added = false;

                        if (data.AbstractText && data.AbstractText.length > 0) {
                                embed.setDescription(data.AbstractText.slice(0, 1000) + (data.AbstractURL ? `\n\n🔗 [Ver más](${data.AbstractURL})` : ""));
                                if (data.Image) embed.setThumbnail(data.Image.startsWith("http") ? data.Image : `https://duckduckgo.com${data.Image}`);
                                added = true;
                        } else if (data.Answer) {
                                embed.setDescription(String(data.Answer).slice(0, 1000));
                                added = true;
                        } else if (data.Definition) {
                                embed.setDescription(`**Definición:** ${data.Definition}\n${data.DefinitionURL ? `🔗 [Fuente](${data.DefinitionURL})` : ""}`);
                                added = true;
                        }

                        const topics = (data.RelatedTopics || []).filter((t) => t.Text && t.FirstURL).slice(0, 5);
                        if (topics.length) {
                                embed.addField(
                                        "Temas relacionados",
                                        topics.map((t, i) => `**${i + 1}.** [${t.Text.slice(0, 80)}](${t.FirstURL})`).join("\n").slice(0, 1024)
                                );
                                added = true;
                        }

                        if (!added) {
                                embed.setDescription(`No encontré una respuesta directa.\n🔗 [Ver resultados completos en DuckDuckGo](https://duckduckgo.com/?q=${encodeURIComponent(q)})`);
                        }

                        return interaction.editReply({ embeds: [embed] });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ Error en la búsqueda: \`${err.message}\``)] });
                }
        });

module.exports = command;
