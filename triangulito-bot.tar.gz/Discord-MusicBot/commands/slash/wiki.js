const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed } = require("discord.js");
const fetch = require("node-fetch");

const command = new SlashCommand()
        .setName("wiki")
        .setDescription("Busca un resumen en Wikipedia")
        .addStringOption((o) => o.setName("tema").setDescription("Sobre qué quieres saber").setRequired(true))
        .addStringOption((o) =>
                o.setName("idioma").setDescription("Idioma de Wikipedia").setRequired(false)
                        .addChoices({ name: "Español", value: "es" }, { name: "Inglés", value: "en" }, { name: "Portugués", value: "pt" }, { name: "Francés", value: "fr" })
        )
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                const tema = interaction.options.getString("tema", true);
                const lang = interaction.options.getString("idioma") || "es";

                try {
                        const searchRes = await fetch(`https://${lang}.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(tema)}&limit=1&namespace=0&format=json`, {
                                headers: { "User-Agent": "Triangulito-Bot/1.0 (Discord)" },
                        });
                        const searchData = await searchRes.json();
                        const title = searchData[1] && searchData[1][0];
                        if (!title) {
                                return interaction.editReply({ embeds: [new MessageEmbed().setColor("YELLOW").setDescription(`🔍 No encontré nada sobre **${tema}** en Wikipedia (${lang}).`)] });
                        }

                        const sumRes = await fetch(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, "_"))}`, {
                                headers: { "User-Agent": "Triangulito-Bot/1.0 (Discord)" },
                        });
                        const sum = await sumRes.json();

                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setTitle(`📚 ${sum.title || title}`)
                                .setURL(sum.content_urls?.desktop?.page || `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(title)}`)
                                .setDescription((sum.extract || "Sin resumen disponible.").slice(0, 2000))
                                .setFooter({ text: `Wikipedia (${lang}) • Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

                        if (sum.thumbnail?.source) embed.setThumbnail(sum.thumbnail.source);
                        if (sum.description) embed.setAuthor({ name: sum.description });

                        return interaction.editReply({ embeds: [embed] });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
