const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("slowmode")
        .setDescription("Activa el modo lento del canal (en segundos, 0 = desactivar)")
        .addIntegerOption((o) => o.setName("segundos").setDescription("Segundos entre mensajes (0-21600)").setMinValue(0).setMaxValue(21600).setRequired(true))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas **Gestionar Canales**.")] });
                }
                const seconds = interaction.options.getInteger("segundos", true);
                try {
                        await interaction.channel.setRateLimitPerUser(seconds, `${interaction.user.tag} configuró slowmode`);
                        const msg = seconds === 0 ? "🐢➡️🐇 Modo lento desactivado." : `🐢 Modo lento: **${seconds} segundos** entre mensajes.`;
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(msg)] });
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
