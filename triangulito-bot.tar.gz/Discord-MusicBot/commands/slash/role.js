const SlashCommand = require("../../lib/SlashCommand");
const { MessageEmbed, Permissions } = require("discord.js");

const command = new SlashCommand()
        .setName("role")
        .setDescription("Da o quita un rol a un usuario")
        .addUserOption((o) => o.setName("usuario").setDescription("Usuario").setRequired(true))
        .addRoleOption((o) => o.setName("rol").setDescription("Rol").setRequired(true))
        .setRun(async (client, interaction) => {
                await interaction.deferReply();
                if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Necesitas **Gestionar Roles**.")] });
                }
                const me = interaction.guild.me || (await interaction.guild.members.fetchMe());
                if (!me.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | El bot necesita **Gestionar Roles**.")] });
                }

                const user = interaction.options.getUser("usuario", true);
                const role = interaction.options.getRole("rol", true);

                if (role.position >= me.roles.highest.position) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Ese rol está por encima del mío, no puedo asignarlo/quitarlo.")] });
                }

                const target = await interaction.guild.members.fetch(user.id).catch(() => null);
                if (!target) return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription("❌ | Usuario no encontrado en el servidor.")] });

                try {
                        if (target.roles.cache.has(role.id)) {
                                await target.roles.remove(role, `${interaction.user.tag} via /role`);
                                return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`➖ Le quité el rol ${role} a **${user.tag}**.`)] });
                        } else {
                                await target.roles.add(role, `${interaction.user.tag} via /role`);
                                return interaction.editReply({ embeds: [new MessageEmbed().setColor(client.config.embedColor).setDescription(`➕ Le di el rol ${role} a **${user.tag}**.`)] });
                        }
                } catch (err) {
                        return interaction.editReply({ embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ | Error: \`${err.message}\``)] });
                }
        });

module.exports = command;
