//JotaroKujo0525 note, this is a deed that i should've done a long time ago
require('dotenv').config()

const http = require("http");
const DiscordMusicBot = require("./lib/DiscordMusicBot");
const { exec } = require("child_process");

// Render requires a web service to listen on a port
const PORT = process.env.PORT || 3000;
http.createServer((req, res) => res.writeHead(200).end("OK")).listen(PORT);

if (process.env.REPL_ID) {
        console.log("Replit system detected, initiating special `unhandledRejection` event listener.")
        process.on('unhandledRejection', (reason, promise) => {
                promise.catch((err) => {
                        if (err.status === 429) {
                                console.log("something went wrong whilst trying to connect to discord gateway, resetting...");
                                exec("kill 1");
                        }
                });
        });
}

const client = new DiscordMusicBot();

console.log("Make sure to fill in the config.js before starting the bot.");

const getClient = () => client;

module.exports = {
        getClient,
};
