---
name: Bug report
about: Report incorrect or unexpected behavior of the Music Bot
title: ""
labels: "s: unverified, type: bug"
assignees: ""
---

<!-- Use Discord for questions: https://discord.gg/sbySMS7m3v -->

## Please describe the problem you are having in as much detail as possible:

## Include a reproducible code sample here, if possible:

```js
// Place your code here
```

## Further details:

- discord.js version:
- Node.js version:
- Operating system:
- Priority this issue should have – please be realistic and elaborate if possible:

## Relevant client options:

- partials: none
- gateway intents: none
- other: none

<!--
Remove the comment and fill out the commit hash if this applies to you:
(While it's not a requirement to test your issue on the master branch, it would make fixing the problem a lot easier for us, so please do so if possible.)

-->
