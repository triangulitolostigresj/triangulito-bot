const { welcome } = require("../util/economyDB");

/**
 * @param {import("../lib/DiscordMusicBot")} client
 * @param {import("discord.js").GuildMember} member
 */
module.exports = async (client, member) => {
  try {
    const cfg = await welcome.get(`welcome:${member.guild.id}`);
    if (!cfg || !cfg.enabled || !cfg.channelId) return;
    const channel = member.guild.channels.cache.get(cfg.channelId);
    if (!channel || !channel.isText()) return;
    const msg = (cfg.message || "👋 ¡Bienvenido {user} a **{server}**!")
      .replace(/{user}/g, `<@${member.id}>`)
      .replace(/{server}/g, member.guild.name)
      .replace(/{count}/g, member.guild.memberCount);
    await channel.send({ content: msg }).catch(() => null);
  } catch (e) {
    client.warn("guildMemberAdd error: " + e.message);
  }
};
