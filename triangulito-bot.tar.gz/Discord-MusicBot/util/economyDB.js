const Jsoning = require("jsoning");
const path = require("path");
const fs = require("fs");

const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const economy = new Jsoning(path.join(dataDir, "economy.json"));
const welcome = new Jsoning(path.join(dataDir, "welcome.json"));

const KEY = (guildId, userId) => `${guildId}:${userId}`;

async function getUser(guildId, userId) {
  const key = KEY(guildId, userId);
  let u = await economy.get(key);
  if (!u) {
    u = { coins: 0, lastDaily: 0, lastWork: 0 };
    await economy.set(key, u);
  }
  return u;
}

async function setUser(guildId, userId, data) {
  await economy.set(KEY(guildId, userId), data);
}

async function addCoins(guildId, userId, amount) {
  const u = await getUser(guildId, userId);
  u.coins = Math.max(0, (u.coins || 0) + amount);
  await setUser(guildId, userId, u);
  return u.coins;
}

async function getTopUsers(guildId, limit = 10) {
  const all = economy.all();
  const entries = Object.entries(all)
    .filter(([k]) => k.startsWith(guildId + ":"))
    .map(([k, v]) => ({ userId: k.split(":")[1], coins: v.coins || 0 }))
    .sort((a, b) => b.coins - a.coins)
    .slice(0, limit);
  return entries;
}

module.exports = {
  economy,
  welcome,
  getUser,
  setUser,
  addCoins,
  getTopUsers,
};
