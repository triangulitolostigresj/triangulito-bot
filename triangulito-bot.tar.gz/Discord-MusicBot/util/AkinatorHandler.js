const { MessageEmbed } = require("discord.js");
const { buildAnswerRows, buildGuessRow } = require("../commands/slash/akinator");

/**
 * @param {import("../lib/DiscordMusicBot")} client
 * @param {import("discord.js").ButtonInteraction} interaction
 */
module.exports = async (client, interaction) => {
        if (!client.akinatorSessions) client.akinatorSessions = new Map();

        const parts = interaction.customId.split("_");
        const ownerId = parts[1];
        const action = parts.slice(2).join("_");

        if (interaction.user.id !== ownerId) {
                return interaction.reply({ content: "❌ Esta partida no es tuya. Usa `/akinator` para empezar la tuya.", ephemeral: true });
        }

        const session = client.akinatorSessions.get(ownerId);
        if (!session) {
                return interaction.update({ embeds: [new MessageEmbed().setColor("RED").setDescription("⌛ Esta partida ya expiró. Inicia una nueva con `/akinator`.")], components: [] }).catch(() => {});
        }
        const aki = session.aki;
        session.lastInteraction = Date.now();

        try {
                if (action === "stop") {
                        client.akinatorSessions.delete(ownerId);
                        return interaction.update({
                                embeds: [new MessageEmbed().setColor("GREY").setDescription("🛑 Partida terminada. ¡Hasta la próxima!")],
                                components: [],
                        });
                }

                if (action === "winyes") {
                        client.akinatorSessions.delete(ownerId);
                        return interaction.update({
                                embeds: [new MessageEmbed().setColor("GOLD").setTitle("🎉 ¡Lo logré!").setDescription("Sabía que te tenía. Gracias por jugar.")],
                                components: [],
                        });
                }

                if (action === "winno") {
                        try {
                                await aki.continue();
                        } catch (err) {
                                client.akinatorSessions.delete(ownerId);
                                return interaction.update({
                                        embeds: [new MessageEmbed().setColor("RED").setDescription("😅 Me rindo, no logré adivinar. ¡Buen personaje!")],
                                        components: [],
                                });
                        }
                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setAuthor({ name: `🧞 Akinator — ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                                .setTitle("Sigamos…")
                                .setDescription(`**${aki.question}**`)
                                .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%` });
                        return interaction.update({ embeds: [embed], components: buildAnswerRows(ownerId, aki.answers) });
                }

                if (action === "back") {
                        try {
                                await aki.back();
                        } catch {
                                return interaction.reply({ content: "❌ No puedo retroceder más.", ephemeral: true });
                        }
                        const embed = new MessageEmbed()
                                .setColor(client.config.embedColor)
                                .setAuthor({ name: `🧞 Akinator — ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                                .setTitle("Pregunta anterior")
                                .setDescription(`**${aki.question}**`)
                                .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%` });
                        return interaction.update({ embeds: [embed], components: buildAnswerRows(ownerId, aki.answers) });
                }

                const answer = parseInt(action, 10);
                if (isNaN(answer) || answer < 0 || answer > 4) {
                        return interaction.reply({ content: "❌ Respuesta inválida.", ephemeral: true });
                }

                await interaction.deferUpdate();
                await aki.step(answer);

                if (aki.progress >= 80 || aki.currentStep >= 78) {
                        try {
                                await aki.win();
                        } catch (err) {
                                const embed = new MessageEmbed()
                                        .setColor(client.config.embedColor)
                                        .setTitle(`Pregunta ${aki.currentStep + 1}`)
                                        .setDescription(`**${aki.question}**`)
                                        .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%` });
                                return interaction.editReply({ embeds: [embed], components: buildAnswerRows(ownerId, aki.answers) });
                        }
                        const guess = aki.answers && aki.answers[0];
                        if (guess && !session.guessed.has(guess.id)) {
                                session.guessed.add(guess.id);
                                const embed = new MessageEmbed()
                                        .setColor("GOLD")
                                        .setAuthor({ name: `🧞 Akinator — ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                                        .setTitle("¿Es este tu personaje?")
                                        .setDescription(`**${guess.name}**\n${guess.description || ""}`)
                                        .setImage(guess.absolute_picture_path || null)
                                        .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%` });
                                return interaction.editReply({ embeds: [embed], components: [buildGuessRow(ownerId)] });
                        }
                }

                const embed = new MessageEmbed()
                        .setColor(client.config.embedColor)
                        .setAuthor({ name: `🧞 Akinator — ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTitle(`Pregunta ${aki.currentStep + 1}`)
                        .setDescription(`**${aki.question}**`)
                        .setFooter({ text: `Progreso: ${Math.floor(aki.progress)}%` });
                return interaction.editReply({ embeds: [embed], components: buildAnswerRows(ownerId, aki.answers) });
        } catch (err) {
                client.logger && client.logger.error && client.logger.error(err.stack || err.toString());
                client.akinatorSessions.delete(ownerId);
                const reply = { embeds: [new MessageEmbed().setColor("RED").setDescription(`❌ Error en Akinator: \`${err.message}\``)], components: [] };
                if (interaction.deferred || interaction.replied) return interaction.editReply(reply).catch(() => {});
                return interaction.update(reply).catch(() => {});
        }
};
